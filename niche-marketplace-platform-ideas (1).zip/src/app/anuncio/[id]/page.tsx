import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { listings, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { currentUser, VERTICALS, MODES, PLANS, FEATURE_PRICE, eur, unit, commissionFor } from "@/lib/core";
import { buyAction, featureAction, messageAction, setStatusAction } from "@/lib/actions";

const OK: Record<string, string> = { publicado: "✅ Anuncio publicado", destacado: "⭐ Anuncio destacado 7 días", pagado: "💳 Pago realizado. El vendedor recibirá su dinero menos la comisión.", mensaje: "✉️ Mensaje enviado al vendedor" };

export default async function Page({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string }> }) {
  const { id } = await params;
  const { ok } = await searchParams;
  const me = await currentUser();
  const [l] = await db.select().from(listings).where(eq(listings.id, Number(id) || 0));
  if (!l) notFound();
  await db.update(listings).set({ views: sql`${listings.views} + 1` }).where(eq(listings.id, l.id));
  const [seller] = await db.select().from(users).where(eq(users.id, l.userId));
  const mine = me?.id === l.userId;
  const featured = l.featuredUntil && new Date(l.featuredUntil) > new Date();
  const pct = await commissionFor(seller.plan);
  const payable = Number(l.price) > 0 && ["venta", "alquiler", "servicio"].includes(l.mode) && l.status === "activo";

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {ok && OK[ok] && <div className="bg-emerald-100 text-emerald-800 p-3 rounded mb-4">{OK[ok]}</div>}
      <p className="text-sm text-slate-500 mb-3"><Link href="/">Inicio</Link> › <Link href={`/?v=${l.vertical}`}>{VERTICALS[l.vertical]?.label}</Link> › {l.category}</p>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-white rounded-xl border overflow-hidden">
          <div className="h-72 bg-gradient-to-br from-emerald-50 to-sky-100 flex items-center justify-center text-9xl">{l.emoji}</div>
          <div className="p-6">
            <div className="flex gap-2 mb-2">
              <span className="text-xs bg-slate-100 px-2 py-1 rounded">{MODES[l.mode]}</span>
              {featured && <span className="text-xs bg-amber-400 px-2 py-1 rounded font-bold">⭐ Destacado</span>}
              {l.status !== "activo" && <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded uppercase">{l.status}</span>}
            </div>
            <h1 className="text-2xl font-bold">{l.title}</h1>
            <p className="text-3xl font-black text-emerald-600 mt-2">{Number(l.price) === 0 ? "Gratis" : eur(l.price)}<span className="text-base text-slate-500 font-normal">{unit(l.priceUnit)}</span></p>
            <p className="text-sm text-slate-500 mt-1">📍 {l.city} · 👁 {l.views + 1} visitas</p>
            {Object.keys(l.meta).length > 0 && (
              <dl className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-5">
                {Object.entries(l.meta).map(([k, v]) => <div key={k} className="bg-slate-50 rounded p-3"><dt className="text-xs text-slate-500">{k}</dt><dd className="font-semibold">{v}</dd></div>)}
              </dl>
            )}
            <p className="whitespace-pre-line mt-4">{l.description}</p>
          </div>
        </div>
        <aside className="space-y-4">
          <div className="bg-white rounded-xl border p-5">
            <p className="font-bold text-lg">{seller.name} {seller.plan !== "free" && <span className="text-xs bg-sky-100 text-sky-700 px-2 py-0.5 rounded">✔ {PLANS[seller.plan].label}</span>}</p>
            <p className="text-sm text-slate-500">Miembro desde {new Date(seller.createdAt).toLocaleDateString("es-ES")}</p>
          </div>
          {mine ? (
            <div className="bg-white rounded-xl border p-5 space-y-3">
              <p className="font-semibold">Gestionar tu anuncio</p>
              {!featured && (
                <form action={featureAction}><input type="hidden" name="id" value={l.id} />
                  <button className="w-full bg-amber-400 font-bold py-2 rounded">⭐ Destacar 7 días ({eur(FEATURE_PRICE)})</button></form>
              )}
              <form action={setStatusAction} className="flex gap-2"><input type="hidden" name="id" value={l.id} /><input type="hidden" name="back" value={`/anuncio/${l.id}`} />
                <button name="status" value={l.status === "activo" ? "pausado" : "activo"} className="flex-1 border py-2 rounded">{l.status === "activo" ? "Pausar" : "Reactivar"}</button>
                <button name="status" value="vendido" className="flex-1 border py-2 rounded">Vendido</button>
              </form>
            </div>
          ) : (
            <>
              {payable && (
                <form action={buyAction} className="bg-white rounded-xl border p-5 space-y-3">
                  <input type="hidden" name="id" value={l.id} />
                  <p className="font-semibold">💳 Pago seguro en la plataforma</p>
                  {l.priceUnit !== "total" && (
                    <label className="block text-sm">Cantidad ({l.priceUnit === "dia" ? "días" : l.priceUnit === "hora" ? "horas" : "meses"})
                      <input type="number" name="qty" min={1} defaultValue={1} className="border rounded w-full px-3 py-2 mt-1" /></label>
                  )}
                  <button className="w-full bg-emerald-600 text-white font-bold py-3 rounded">{l.mode === "alquiler" ? "Reservar y pagar" : l.mode === "servicio" ? "Contratar" : "Comprar ahora"}</button>
                  <p className="text-xs text-slate-500">Tu dinero queda protegido hasta la entrega. La plataforma retiene un {pct}% de comisión al vendedor.</p>
                </form>
              )}
              <form action={messageAction} className="bg-white rounded-xl border p-5 space-y-2">
                <input type="hidden" name="id" value={l.id} />
                <p className="font-semibold">{l.mode === "empleo" ? "📝 Postularme" : "✉️ Contactar"}</p>
                <textarea name="body" required rows={3} placeholder={l.mode === "empleo" ? "Cuéntale tu experiencia…" : "Hola, ¿sigue disponible?"} className="border rounded w-full p-2 text-sm" />
                <button className="w-full border border-emerald-600 text-emerald-700 font-semibold py-2 rounded">{me ? "Enviar" : "Inicia sesión para enviar"}</button>
              </form>
            </>
          )}
        </aside>
      </div>
    </div>
  );
}
