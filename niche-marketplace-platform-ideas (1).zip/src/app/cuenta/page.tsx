import Link from "next/link";
import { db } from "@/db";
import { listings, messages, transactions, users } from "@/db/schema";
import { desc, eq, or, sql } from "drizzle-orm";
import { currentUser, PLANS, eur, MODES } from "@/lib/core";
import { loginAction, registerAction, logoutAction, setStatusAction } from "@/lib/actions";

export default async function Cuenta({ searchParams }: { searchParams: Promise<{ err?: string; ok?: string }> }) {
  const { err, ok } = await searchParams;
  const u = await currentUser();
  const inp = "border rounded w-full px-3 py-2";
  if (!u) return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      {err && <div className="bg-red-100 text-red-700 p-3 rounded mb-4">{err}</div>}
      <div className="grid md:grid-cols-2 gap-6">
        <form action={loginAction} className="bg-white border rounded-xl p-6 space-y-3">
          <h2 className="text-xl font-bold">Entrar</h2>
          <input name="email" type="email" placeholder="Email" required className={inp} />
          <input name="password" type="password" placeholder="Contraseña" required className={inp} />
          <button className="w-full bg-emerald-600 text-white py-2 rounded font-semibold">Entrar</button>
          <p className="text-xs text-slate-500">Demo: laura@demo.es / demo123 · admin@todomarket.es / admin123</p>
        </form>
        <form action={registerAction} className="bg-white border rounded-xl p-6 space-y-3">
          <h2 className="text-xl font-bold">Crear cuenta gratis</h2>
          <input name="name" placeholder="Nombre o empresa" required className={inp} />
          <input name="email" type="email" placeholder="Email" required className={inp} />
          <input name="city" placeholder="Ciudad" className={inp} />
          <input name="password" type="password" placeholder="Contraseña (mín. 4)" required className={inp} />
          <button className="w-full bg-slate-900 text-white py-2 rounded font-semibold">Registrarme</button>
        </form>
      </div>
    </div>
  );

  const mine = await db.select().from(listings).where(eq(listings.userId, u.id)).orderBy(desc(listings.createdAt));
  const sales = await db.select().from(transactions).where(eq(transactions.sellerId, u.id)).orderBy(desc(transactions.createdAt));
  const purchases = await db.select().from(transactions).where(eq(transactions.buyerId, u.id)).orderBy(desc(transactions.createdAt));
  const msgs = await db.select({ m: messages, from: users.name, title: listings.title }).from(messages)
    .leftJoin(users, eq(users.id, messages.fromUserId)).leftJoin(listings, eq(listings.id, messages.listingId))
    .where(or(eq(messages.toUserId, u.id), eq(messages.fromUserId, u.id))).orderBy(desc(messages.createdAt)).limit(30);
  const net = sales.reduce((a, t) => a + Number(t.sellerNet), 0);
  const views = mine.reduce((a, l) => a + l.views, 0);
  void sql;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {ok && <div className="bg-emerald-100 text-emerald-800 p-3 rounded">✅ Plan actualizado</div>}
      <div className="flex flex-wrap items-center gap-4">
        <div><h1 className="text-3xl font-bold">Hola, {u.name}</h1><p className="text-slate-500">Plan <b>{PLANS[u.plan].label}</b> · comisión {PLANS[u.plan].commission}% · <Link href="/planes" className="text-emerald-600 underline">cambiar</Link></p></div>
        <form action={logoutAction} className="ml-auto"><button className="border px-4 py-2 rounded">Salir</button></form>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[["Anuncios", mine.length], ["Visitas totales", views], ["Ventas/alquileres", sales.length], ["Ingresos netos", eur(net)]].map(([k, v]) => (
          <div key={k} className="bg-white border rounded-xl p-4"><p className="text-xs text-slate-500">{k}</p><p className="text-2xl font-bold">{v}</p></div>
        ))}
      </div>
      <section className="bg-white border rounded-xl p-5">
        <h2 className="font-bold mb-3">Mis anuncios</h2>
        {mine.length === 0 && <p className="text-sm text-slate-500">Aún no tienes anuncios. <Link href="/publicar" className="text-emerald-600 underline">Publica ahora</Link></p>}
        <div className="divide-y">
          {mine.map((l) => (
            <div key={l.id} className="py-2 flex items-center gap-3 text-sm">
              <span className="text-2xl">{l.emoji}</span>
              <Link href={`/anuncio/${l.id}`} className="flex-1 hover:underline">{l.title} <span className="text-slate-400">· {MODES[l.mode]} · {eur(l.price)} · 👁 {l.views}</span></Link>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-100">{l.status}</span>
              <form action={setStatusAction}><input type="hidden" name="id" value={l.id} /><button name="status" value="borrar" className="text-red-600 text-xs">Borrar</button></form>
            </div>
          ))}
        </div>
      </section>
      <div className="grid md:grid-cols-2 gap-6">
        <section className="bg-white border rounded-xl p-5">
          <h2 className="font-bold mb-3">Ventas (desglose de comisión)</h2>
          <table className="w-full text-sm"><thead className="text-left text-slate-500"><tr><th>Fecha</th><th>Total</th><th>Comisión</th><th>Recibes</th></tr></thead>
            <tbody>{sales.map((t) => <tr key={t.id} className="border-t"><td>{new Date(t.createdAt).toLocaleDateString("es-ES")}</td><td>{eur(t.amount)}</td><td className="text-red-600">-{eur(t.platformFee)}</td><td className="font-semibold">{eur(t.sellerNet)}</td></tr>)}</tbody></table>
        </section>
        <section className="bg-white border rounded-xl p-5">
          <h2 className="font-bold mb-3">Mis pagos</h2>
          <table className="w-full text-sm"><tbody>{purchases.map((t) => <tr key={t.id} className="border-t"><td>{new Date(t.createdAt).toLocaleDateString("es-ES")}</td><td>{t.kind}</td><td>{t.note}</td><td className="text-right">{eur(t.amount)}</td></tr>)}</tbody></table>
        </section>
      </div>
      <section className="bg-white border rounded-xl p-5">
        <h2 className="font-bold mb-3">Mensajes</h2>
        {msgs.length === 0 && <p className="text-sm text-slate-500">Sin mensajes.</p>}
        {msgs.map(({ m, from, title }) => (
          <div key={m.id} className="border-t py-2 text-sm">
            <p><b>{m.fromUserId === u.id ? "Tú" : from}</b> sobre <Link href={`/anuncio/${m.listingId}`} className="text-emerald-700">{title}</Link>: {m.body}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
