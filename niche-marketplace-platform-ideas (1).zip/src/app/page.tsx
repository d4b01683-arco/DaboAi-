import Link from "next/link";
import { db } from "@/db";
import { listings, ads } from "@/db/schema";
import { and, desc, eq, ilike, or, sql, SQL, asc } from "drizzle-orm";
import { ensureDb, VERTICALS, MODES } from "@/lib/core";
import Card from "@/components/Card";

type SP = Promise<Record<string, string | undefined>>;

export default async function Home({ searchParams }: { searchParams: SP }) {
  await ensureDb();
  const p = await searchParams;
  const conds: SQL[] = [eq(listings.status, "activo")];
  if (p.q) conds.push(or(ilike(listings.title, `%${p.q}%`), ilike(listings.description, `%${p.q}%`), ilike(listings.category, `%${p.q}%`))!);
  if (p.v && VERTICALS[p.v]) conds.push(eq(listings.vertical, p.v));
  if (p.c) conds.push(eq(listings.category, p.c));
  if (p.m) conds.push(eq(listings.mode, p.m));
  if (p.city) conds.push(ilike(listings.city, `%${p.city}%`));
  if (p.min) conds.push(sql`${listings.price} >= ${Number(p.min)}`);
  if (p.max) conds.push(sql`${listings.price} <= ${Number(p.max)}`);
  const order = p.sort === "barato" ? [asc(listings.price)] : p.sort === "caro" ? [desc(listings.price)] : [desc(listings.createdAt)];
  const rows = await db.select().from(listings).where(and(...conds))
    .orderBy(sql`(${listings.featuredUntil} > now()) desc nulls last`, ...order).limit(60);
  const banners = await db.select().from(ads).where(eq(ads.active, true));
  const banner = banners.length ? banners[Math.floor(Math.random() * banners.length)] : null;
  const filtered = p.q || p.v || p.m || p.city || p.c;

  return (
    <div>
      {!filtered && (
        <section className="bg-gradient-to-r from-emerald-600 to-teal-500 text-white">
          <div className="max-w-7xl mx-auto px-4 py-14">
            <h1 className="text-4xl sm:text-5xl font-black max-w-3xl">Compra, vende y alquila lo que sea, cerca de ti.</h1>
            <p className="mt-3 text-lg opacity-90">Coches, motos, pisos, ropa, comida casera, patines, cámaras, servicios, empleos, traspasos y eventos. Publicar es gratis.</p>
          </div>
        </section>
      )}
      <div className="max-w-7xl mx-auto px-4">
        <form className="bg-white rounded-xl shadow p-3 -mt-6 relative grid grid-cols-2 md:grid-cols-7 gap-2 text-sm">
          <input name="q" defaultValue={p.q} placeholder="¿Qué buscas?" className="col-span-2 border rounded px-3 py-2" />
          <select name="v" defaultValue={p.v ?? ""} className="border rounded px-2">
            <option value="">Todas las secciones</option>
            {Object.entries(VERTICALS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
          <select name="m" defaultValue={p.m ?? ""} className="border rounded px-2">
            <option value="">Venta / Alquiler / ...</option>
            {Object.entries(MODES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <input name="city" defaultValue={p.city} placeholder="Ciudad" className="border rounded px-3 py-2" />
          <select name="sort" defaultValue={p.sort ?? ""} className="border rounded px-2">
            <option value="">Más recientes</option><option value="barato">Más baratos</option><option value="caro">Más caros</option>
          </select>
          <button className="bg-emerald-600 text-white rounded font-semibold py-2">Buscar</button>
        </form>

        <div className="flex gap-2 overflow-x-auto py-6">
          {Object.entries(VERTICALS).map(([k, v]) => (
            <Link key={k} href={`/?v=${k}`} className={`shrink-0 flex flex-col items-center w-28 p-3 rounded-xl border bg-white hover:border-emerald-500 ${p.v === k ? "border-emerald-500 bg-emerald-50" : ""}`}>
              <span className="text-3xl">{v.emoji}</span><span className="text-xs text-center mt-1 font-medium">{v.label}</span>
            </Link>
          ))}
        </div>
        {p.v && VERTICALS[p.v] && (
          <div className="flex flex-wrap gap-2 mb-4">
            {VERTICALS[p.v].cats.map((c) => (
              <Link key={c} href={`/?v=${p.v}&c=${encodeURIComponent(c)}`} className={`text-xs px-3 py-1 rounded-full border ${p.c === c ? "bg-emerald-600 text-white" : "bg-white"}`}>{c}</Link>
            ))}
          </div>
        )}

        {banner && (
          <a href={banner.url} className="block mb-6 rounded-xl bg-amber-50 border border-amber-200 p-4 text-sm">
            <span className="text-[10px] uppercase text-amber-700 font-bold mr-2">Publicidad</span>
            <b>{banner.brand}</b> — {banner.text}
          </a>
        )}

        <h2 className="text-xl font-bold mb-3">{filtered ? `${rows.length} resultados` : "Últimos anuncios"}</h2>
        {rows.length === 0 ? <p className="text-slate-500 py-10 text-center">No hay anuncios. <Link href="/publicar" className="text-emerald-600 underline">¡Sé el primero en publicar!</Link></p> : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {rows.map((l) => <Card key={l.id} l={l} />)}
          </div>
        )}
      </div>
    </div>
  );
}
