import { currentUser, isLaunch, PLANS, FEATURE_PRICE, PAID_LISTING_PRICE, eur } from "@/lib/core";
import { subscribeAction } from "@/lib/actions";

export default async function Planes({ searchParams }: { searchParams: Promise<{ limit?: string }> }) {
  const u = await currentUser();
  const { limit } = await searchParams;
  const launch = await isLaunch();
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      {limit && <div className="bg-amber-100 p-3 rounded mb-6">Has alcanzado el límite de anuncios de tu plan. Mejóralo para seguir publicando.</div>}
      {launch && <div className="bg-amber-100 border border-amber-300 p-4 rounded mb-6 text-center font-semibold">🎁 Oferta de lanzamiento: todos los planes son GRATIS ahora mismo. ¡Hazte PRO sin pagar nada!</div>}
      <h1 className="text-4xl font-black text-center">Publica gratis. Crece con PRO.</h1>
      <p className="text-center text-slate-500 mt-2">Solo cobramos comisión cuando vendes o alquilas a través del pago seguro.</p>
      <div className="grid md:grid-cols-3 gap-6 mt-10">
        {Object.entries(PLANS).map(([k, p]) => (
          <div key={k} className={`bg-white rounded-2xl border p-6 flex flex-col ${k === "pro" ? "ring-2 ring-emerald-500 scale-105" : ""}`}>
            {k === "pro" && <span className="self-start text-xs bg-emerald-600 text-white px-2 py-0.5 rounded mb-2">Más popular</span>}
            <h2 className="text-xl font-bold">{p.label}</h2>
            <p className="text-4xl font-black mt-2">{p.price === 0 ? "0 €" : eur(p.price)}<span className="text-base font-normal text-slate-500">/mes</span></p>
            <ul className="mt-4 space-y-2 text-sm flex-1">{p.perks.map((x) => <li key={x}>✅ {x}</li>)}</ul>
            <form action={subscribeAction} className="mt-6"><input type="hidden" name="plan" value={k} />
              <button disabled={u?.plan === k} className="w-full py-3 rounded font-bold bg-emerald-600 text-white disabled:bg-slate-200 disabled:text-slate-500">{u?.plan === k ? "Tu plan actual" : "Elegir " + p.label}</button></form>
          </div>
        ))}
      </div>
      <div className="grid sm:grid-cols-3 gap-4 mt-12 text-sm">
        <div className="bg-white border rounded-xl p-5"><b>⭐ Destacados</b><p>Tu anuncio arriba y en portada 7 días por {eur(FEATURE_PRICE)}.</p></div>
        <div className="bg-white border rounded-xl p-5"><b>🚗🏠 Motor, inmobiliaria y traspasos</b><p>{eur(PAID_LISTING_PRICE)} por anuncio en plan gratuito. Incluido en PRO/Empresa.</p></div>
        <div className="bg-white border rounded-xl p-5"><b>📢 Publicidad para marcas</b><p>Banners segmentados por sección desde 49 €/mes. Contacta con nosotros.</p></div>
      </div>
    </div>
  );
}
