import Link from "next/link";
import { currentUser, VERTICALS, MODES, PAID_LISTING_VERTICALS, PAID_LISTING_PRICE, FEATURE_PRICE, PLANS } from "@/lib/core";
import { createListingAction } from "@/lib/actions";
import PublishForm from "@/components/PublishForm";

export default async function Publicar() {
  const u = await currentUser();
  if (!u) return (
    <div className="max-w-md mx-auto text-center py-20">
      <p className="text-5xl">📝</p><h1 className="text-2xl font-bold mt-3">Publica gratis en 1 minuto</h1>
      <Link href="/cuenta" className="inline-block mt-4 bg-emerald-600 text-white px-6 py-3 rounded-full">Crear cuenta / Entrar</Link>
    </div>
  );
  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-1">Publicar anuncio</h1>
      <p className="text-slate-500 mb-5 text-sm">Plan {PLANS[u.plan].label}: hasta {PLANS[u.plan].maxListings > 1000 ? "ilimitados" : PLANS[u.plan].maxListings} anuncios activos. <Link href="/planes" className="text-emerald-600 underline">Mejorar plan</Link></p>
      <PublishForm verticals={VERTICALS} modes={MODES} action={createListingAction} paidVerticals={PAID_LISTING_VERTICALS} paidPrice={PAID_LISTING_PRICE} featurePrice={FEATURE_PRICE} isFree={u.plan === "free"} />
    </div>
  );
}
